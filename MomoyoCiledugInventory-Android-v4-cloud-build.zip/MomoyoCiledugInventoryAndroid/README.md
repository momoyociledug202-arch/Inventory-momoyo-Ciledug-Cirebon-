# Momoyo Ciledug Inventory — Android

Web app:
https://momoyo-ciledug-inventory.ai.studio/

Branding:
- Uses the supplied Momoyo Ciledug Cirebon Inventory logo as the Android launcher icon.

Fitur:
- WebView dengan JavaScript + DOM storage.
- Download file dari web app ke folder Download Android.
- Notifikasi saat download selesai.
- Pemilih file Android untuk upload.
- Tombol Back Android mengikuti riwayat halaman web.

Build:
1. Buka folder ini di Android Studio.
2. Sync Gradle.
3. Build APK untuk instalasi atau Generate Signed Bundle/APK untuk distribusi.
